CREATE
    VIEW new_view_1
    AS
    SELECT * FROM <table>